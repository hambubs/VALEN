
  # valentines day

  This is a code bundle for valentines day. The original project is available at https://www.figma.com/design/zgyGjEdu3ajd3kzvNIljzV/valentines-day.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  